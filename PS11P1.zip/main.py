
#problem 1

def dl1(mylist):
  n = int(input("Number of items for your list: "))
  for n in range (0,n,1):
    s = int(input("Enter an intger: "))
    mylist.append(s)
  return mylist 

def displaylist(mylist):
  for item in mylist:
    print(item)

mylist = []
mylist = dl1(mylist)
displaylist(mylist)
print(mylist)

#problem 2

mylist.insert(0,99)
print(mylist)

#problem 3

mylist[0]= 100
print(mylist)

#problem 4

mylist2 = [500,600,700,800,900]
mylist.extend(mylist2)
print(mylist)

#problem 5

mylist.remove(800)
print(mylist)

#probelm 6

mylist.pop(2) 
print(mylist)

#problem 7

gradelist = ["A","B","C","A","A","C"]

#problem 8

print("Count of A's in grades: ",gradelist.count("A"))

#problem 9 

print("Position of B in grades: ",gradelist.index("B"))

#problem 10

def seqsearch(gradelist,gsearch):
  l = len(gradelist)
  sindex = -1
  for y in range (0,l,1):
    if gradelist[y] == gsearch:
      sindex = y 
  return sindex

response = input("Do you want to search for a grade? (Yes or No): ")

while response == "Yes":
  gsearch = input("Enter grade searching for: ")

  i = seqsearch(gradelist,gsearch)

  if i == -1:
    print(gsearch,"isn't in the list") 
  else:
    print(gsearch,"is in the list")
  response = input("Do you want to search for a grade? (Yes or No): ")

#problem 11

gradelist.clear()
print(gradelist)

#problem 12

#gradelist.delete()
#print(gradelist)

#problem 13

playerlist= ("Rizzo", "Davis", "Baez", "Happ", "Bryan")

#problem 14

def diplay(playerlist):
  l = len(playerlist)
  for y in range (0,l,1):
    print(playerlist[y])

diplay(playerlist)

#problem 15

playerlist2= ("Rizzo", "Davis", "Baez", "Happ", "Bryan")

#problem 16 

def diplayr(playerlist2):
  l = len(playerlist2)
  for y in range (l-1,-1,-1):
    print(playerlist2[y])

diplayr(playerlist2)


